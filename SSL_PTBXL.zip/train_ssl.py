import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
import numpy as np
import os
import argparse
import random
from tqdm import tqdm

from dataset import PTBXLContrastiveDataset
from models import ResNet1D_Encoder, InceptionTime_Encoder, ProjectionHead
from loss import NTXentLoss


def get_dummy_contrastive_data(num_samples=800, aug_type='physiological'):
    print("WARNING: Using dummy contrastive data. Please configure correct data path.")
    X = torch.randn(num_samples, 12, 1000)

    class DummyContrastiveDataset(Dataset):
        def __init__(self, data, aug_type='physiological'):
            self.data = data
            self.aug_type = aug_type

        def __len__(self):
            return len(self.data)

        def __getitem__(self, idx):
            x = self.data[idx]
            if self.aug_type == 'physiological':
                aug1 = x + torch.randn_like(x) * 0.1
                aug2 = x * float(np.random.uniform(0.7, 1.3))
            else:
                aug1 = x + torch.randn_like(x) * 0.05
                aug2 = x * float(np.random.uniform(0.8, 1.2))
            return aug1, aug2

    return DummyContrastiveDataset(X, aug_type)


# Hardcoded configuration parameters. Modify these values directly before running.
CONFIG = {
    'data_path': 'use_data/ptb-xl',
    'backbone': 'resnet',  # options: 'resnet', 'inceptiontime'
    'aug_type': 'physiological',  # options: 'physiological', 'naive'
    'batch_size': 1024,
    'epochs': 150,
    'lr': 2e-3,
    'weight_decay': 1e-4,
    'early_stop_patience': 15,
    'early_stop_min_delta': 1e-4,
    'temperature': 0.5,
    'seed': 42,
    'allow_dummy': False,
    'include_seed_in_path': False,
    'num_workers': 8
}


class Hyperparams:
    def __init__(self, **entries):
        self.__dict__.update(entries)


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def get_save_root(args):
    save_root = os.path.join('save', args.backbone)
    if getattr(args, 'include_seed_in_path', False):
        save_root = os.path.join(save_root, f"seed_{args.seed}")
    return save_root


def train_ssl(config_overrides=None):
    config = CONFIG.copy()
    if config_overrides:
        config.update(config_overrides)
    args = Hyperparams(**config)
    set_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    print(f"Config: Epochs={args.epochs}, Batch Size={args.batch_size}, LR={args.lr}, Temperature={args.temperature}")

    # Check data path and load datasets
    if os.path.exists(os.path.join(args.data_path, 'ptbxl_database.csv')):
        print(f"Loading PTB-XL dataset from {args.data_path} with augmentation: {args.aug_type}")
        train_dataset = PTBXLContrastiveDataset(args.data_path, sampling_rate=100, split='train',
                                                aug_type=args.aug_type)
        val_dataset = PTBXLContrastiveDataset(args.data_path, sampling_rate=100, split='val', aug_type=args.aug_type)
    else:
        if not args.allow_dummy:
            raise FileNotFoundError(
                f"PTB-XL database not found at {args.data_path}. "
                "Set CONFIG['data_path'] to the real dataset path or CONFIG['allow_dummy']=True for debugging."
            )
        print(f"PTB-XL database not found at {args.data_path}. Falling back to dummy data with augmentation: {args.aug_type}")
        train_dataset = get_dummy_contrastive_data(800, aug_type=args.aug_type)
        val_dataset = get_dummy_contrastive_data(200, aug_type=args.aug_type)

    # Use drop_last=True for NT-Xent to avoid single-sample or small final batch issues
    loader_kwargs = {
        'num_workers': args.num_workers,
        'pin_memory': device.type == 'cuda',
        'persistent_workers': args.num_workers > 0,
    }
    if args.num_workers > 0:
        loader_kwargs['prefetch_factor'] = 4

    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, drop_last=True, **loader_kwargs)
    val_loader = DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False, drop_last=True, **loader_kwargs)

    # Instantiate model components
    if args.backbone == 'resnet':
        encoder = ResNet1D_Encoder(in_channels=12).to(device)
        in_dim = 512
    elif args.backbone == 'inceptiontime':
        encoder = InceptionTime_Encoder(in_channels=12).to(device)
        in_dim = 128
    else:
        raise ValueError(f"Unknown backbone: {args.backbone}")

    projection_head = ProjectionHead(in_dim=in_dim, hidden_dim=256, out_dim=128).to(device)
    criterion = NTXentLoss(temperature=args.temperature).to(device)

    # We optimize both encoder and projection head
    optimizer = optim.AdamW(
        list(encoder.parameters()) + list(projection_head.parameters()),
        lr=args.lr,
        weight_decay=args.weight_decay,
    )

    save_dir = os.path.join(get_save_root(args), 'pretrain', args.aug_type)
    os.makedirs(save_dir, exist_ok=True)
    best_val_loss = float('inf')
    epochs_without_improvement = 0

    for epoch in range(args.epochs):
        # Training Phase
        encoder.train()
        projection_head.train()
        train_loss = 0.0

        for aug1, aug2 in tqdm(train_loader, desc=f"SSL Epoch {epoch + 1}/{args.epochs}"):
            aug1, aug2 = aug1.to(device, non_blocking=True), aug2.to(device, non_blocking=True)

            optimizer.zero_grad()

            # Forward pass: extract features
            feat1 = encoder(aug1)
            feat2 = encoder(aug2)

            # Project to lower dim space
            proj1 = projection_head(feat1)
            proj2 = projection_head(feat2)

            loss = criterion(proj1, proj2)
            loss.backward()
            optimizer.step()

            train_loss += loss.item()

        # Validation Phase
        encoder.eval()
        projection_head.eval()
        val_loss = 0.0

        with torch.no_grad():
            for aug1, aug2 in val_loader:
                aug1, aug2 = aug1.to(device, non_blocking=True), aug2.to(device, non_blocking=True)

                feat1 = encoder(aug1)
                feat2 = encoder(aug2)

                proj1 = projection_head(feat1)
                proj2 = projection_head(feat2)

                loss = criterion(proj1, proj2)
                val_loss += loss.item()

        mean_train_loss = train_loss / len(train_loader)
        mean_val_loss = val_loss / len(val_loader) if len(val_loader) > 0 else 0.0

        print(f"Epoch {epoch + 1:02d}: Train Loss: {mean_train_loss:.4f} | Val Loss: {mean_val_loss:.4f}")

        # Save best weights based on validation loss
        if mean_val_loss < best_val_loss - args.early_stop_min_delta:
            best_val_loss = mean_val_loss
            epochs_without_improvement = 0
            best_path = os.path.join(save_dir, 'best_ssl_encoder.pth')
            torch.save(encoder.state_dict(), best_path)
            print(f" -> Saved new best encoder weights to {best_path}")
        else:
            epochs_without_improvement += 1
            if epochs_without_improvement >= args.early_stop_patience:
                print(
                    f"SSL early stopping at epoch {epoch + 1:02d}; "
                    f"best validation loss: {best_val_loss:.4f}"
                )
                break

    # Save final weights
    final_path = os.path.join(save_dir, 'final_ssl_encoder.pth')
    torch.save(encoder.state_dict(), final_path)
    print(f"Pre-training finished. Final encoder saved to {final_path}")


if __name__ == "__main__":
    train_ssl()
