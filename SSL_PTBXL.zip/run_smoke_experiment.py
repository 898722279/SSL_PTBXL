from run_experiments import CONFIG, run_all


CONFIG.update({
    'backbones': ['resnet'],
    'ssl_aug_types': ['morphology_physio'],
    'label_fractions': [0.01],
    'seeds': [901],
    'ssl_epochs': 1,
    'downstream_epochs': 1,
    'run_ssl': True,
    'run_downstream': True,
    'run_ptbxl_eval': True,
    'run_cpsc_eval': False,
})


if __name__ == "__main__":
    run_all()
