import torch
import torch.nn as nn
import torch.nn.functional as F

class BasicBlock1D(nn.Module):
    expansion = 1

    def __init__(self, in_channels, out_channels, stride=1, downsample=None):
        super(BasicBlock1D, self).__init__()
        self.conv1 = nn.Conv1d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm1d(out_channels)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv1d(out_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm1d(out_channels)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.relu(out)

        return out

class ResNet1D_Encoder(nn.Module):
    def __init__(self, in_channels=12):
        super(ResNet1D_Encoder, self).__init__()
        self.in_channels = 64
        
        self.conv1 = nn.Conv1d(in_channels, 64, kernel_size=7, stride=2, padding=3, bias=False)
        self.bn1 = nn.BatchNorm1d(64)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool1d(kernel_size=3, stride=2, padding=1)
        
        self.layer1 = self._make_layer(64, 2, stride=1)
        self.layer2 = self._make_layer(128, 2, stride=2)
        self.layer3 = self._make_layer(256, 2, stride=2)
        self.layer4 = self._make_layer(512, 2, stride=2)
        
        self.avgpool = nn.AdaptiveAvgPool1d(1)

    def _make_layer(self, out_channels, blocks, stride=1):
        downsample = None
        if stride != 1 or self.in_channels != out_channels * BasicBlock1D.expansion:
            downsample = nn.Sequential(
                nn.Conv1d(self.in_channels, out_channels * BasicBlock1D.expansion, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm1d(out_channels * BasicBlock1D.expansion),
            )

        layers = []
        layers.append(BasicBlock1D(self.in_channels, out_channels, stride, downsample))
        self.in_channels = out_channels * BasicBlock1D.expansion
        for _ in range(1, blocks):
            layers.append(BasicBlock1D(self.in_channels, out_channels))

        return nn.Sequential(*layers)

    def forward(self, x):
        # Input shape: [batch_size, 12, 1000]
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)

        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)

        x = self.avgpool(x)
        x = torch.flatten(x, 1) # [batch_size, 512]
        return x

class InceptionModule1D(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=40, bottleneck=True):
        super(InceptionModule1D, self).__init__()
        # out_channels must be divisible by 4, as the 4 branches are concatenated.
        assert out_channels % 4 == 0, "out_channels must be divisible by 4"
        nf = out_channels // 4
        
        self.bottleneck = nn.Conv1d(in_channels, nf, kernel_size=1, bias=False) if bottleneck and in_channels > 1 else nn.Identity()
        
        # Parallel branches with different kernel sizes
        ks = [kernel_size, kernel_size // 2, kernel_size // 4]
        # Ensure kernel sizes are odd so padding can be symmetric
        ks = [k if k % 2 != 0 else max(1, k - 1) for k in ks]
        
        conv_in_channels = nf if (bottleneck and in_channels > 1) else in_channels
        self.convs = nn.ModuleList([
            nn.Conv1d(conv_in_channels, nf, kernel_size=k, padding=k//2, bias=False)
            for k in ks
        ])
        
        self.maxpool = nn.MaxPool1d(kernel_size=3, stride=1, padding=1)
        self.conv_pool = nn.Conv1d(in_channels, nf, kernel_size=1, bias=False)
        
        self.bn = nn.BatchNorm1d(out_channels)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        # x: [batch_size, in_channels, length]
        x_bottleneck = self.bottleneck(x)
        
        out_convs = [conv(x_bottleneck) for conv in self.convs]
        out_pool = self.conv_pool(self.maxpool(x))
        
        out = torch.cat(out_convs + [out_pool], dim=1)
        out = self.bn(out)
        return self.relu(out)

class InceptionTime1D_Encoder(nn.Module):
    def __init__(self, in_channels=12, out_channels=128, num_modules=6, kernel_size=40, bottleneck=True):
        super(InceptionTime1D_Encoder, self).__init__()
        
        self.num_modules = num_modules
        self.modules_list = nn.ModuleList()
        
        for i in range(num_modules):
            module_in_channels = in_channels if i == 0 else out_channels
            self.modules_list.append(
                InceptionModule1D(module_in_channels, out_channels, kernel_size=kernel_size, bottleneck=bottleneck)
            )
            
        # Shortcuts every 3 modules
        self.shortcuts = nn.ModuleList()
        for i in range(0, num_modules, 3):
            shortcut_in = in_channels if i == 0 else out_channels
            if shortcut_in != out_channels:
                self.shortcuts.append(
                    nn.Sequential(
                        nn.Conv1d(shortcut_in, out_channels, kernel_size=1, bias=False),
                        nn.BatchNorm1d(out_channels)
                    )
                )
            else:
                self.shortcuts.append(nn.Identity())
                
        self.avgpool = nn.AdaptiveAvgPool1d(1)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        # Input shape: [batch_size, in_channels, length]
        res = x
        for i in range(self.num_modules):
            x = self.modules_list[i](x)
            if (i + 1) % 3 == 0:
                shortcut_idx = i // 3
                shortcut_connection = self.shortcuts[shortcut_idx](res)
                x = x + shortcut_connection
                x = self.relu(x)
                res = x
        x = self.avgpool(x)
        x = torch.flatten(x, 1) # [batch_size, out_channels]
        return x

class ProjectionHead(nn.Module):
    def __init__(self, in_dim=512, hidden_dim=256, out_dim=128):
        super(ProjectionHead, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden_dim, bias=False),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, out_dim, bias=True)
        )

    def forward(self, x):
        return self.net(x)

class ECGClassifier(nn.Module):
    def __init__(self, in_dim=512, num_classes=5):
        super(ECGClassifier, self).__init__()
        self.fc = nn.Linear(in_dim, num_classes)

    def forward(self, x):
        return self.fc(x)

InceptionTime_Encoder = InceptionTime1D_Encoder
