import torch
import torch.nn as nn
import torch.nn.functional as F

class NTXentLoss(nn.Module):
    def __init__(self, temperature=0.5):
        super(NTXentLoss, self).__init__()
        self.temperature = temperature

    def forward(self, z_i, z_j):
        """
        Computes the NT-Xent (Normalized Temperature-scaled Cross Entropy) loss.
        
        Args:
            z_i (torch.Tensor): Projection embeddings for the first augmented view of the batch. Shape: [batch_size, out_dim]
            z_j (torch.Tensor): Projection embeddings for the second augmented view of the batch. Shape: [batch_size, out_dim]
            
        Returns:
            torch.Tensor: The computed scalar contrastive loss.
        """
        batch_size = z_i.size(0)
        
        # L2 normalization of projection embeddings
        z_i_norm = F.normalize(z_i, dim=1)
        z_j_norm = F.normalize(z_j, dim=1)
        
        # Concatenate normalized representations of both views
        representations = torch.cat([z_i_norm, z_j_norm], dim=0)  # [2 * batch_size, out_dim]
        
        # Cosine similarity matrix scaled by temperature
        similarity_matrix = torch.matmul(representations, representations.T) / self.temperature  # [2 * batch_size, 2 * batch_size]
        
        # Create a mask to filter out self-similarity (the diagonal)
        mask = torch.eye(2 * batch_size, dtype=torch.bool, device=z_i.device)
        
        # Fill self-similarity values on the diagonal with a large negative value
        similarity_matrix = similarity_matrix.masked_fill(mask, -1e9)
        
        # Construct target indices. For view 1 (indices 0 to batch_size - 1), the positive pair
        # is at index k + batch_size. For view 2 (indices batch_size to 2 * batch_size - 1),
        # the positive pair is at index k - batch_size.
        targets = torch.arange(2 * batch_size, device=z_i.device)
        targets[:batch_size] = targets[:batch_size] + batch_size
        targets[batch_size:] = targets[batch_size:] - batch_size
        
        loss = F.cross_entropy(similarity_matrix, targets)
        return loss
