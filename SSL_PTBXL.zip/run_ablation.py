from run_experiments import CONFIG, run_all


CONFIG.update({
    'backbones': ['resnet', 'inceptiontime'],
    'ssl_aug_types': [
        'physiological',
        'ablation_without_baseline_wander',
        'ablation_without_emg_noise',
        'ablation_without_electrode_motion',
        'ablation_without_powerline_interference',
    ],
    'label_fractions': [0.10, 1.0],
    'seeds': [42, 43, 44],
    'ssl_epochs': 150,
    'downstream_epochs': 50,
    'run_ssl': True,
    'run_downstream': True,
    'run_ptbxl_eval': True,
    'run_cpsc_eval': False,
})


if __name__ == "__main__":
    run_all()
