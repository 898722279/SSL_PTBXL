from torch.utils.data import DataLoader
from tqdm import tqdm

from dataset import CPSC2018Dataset, PTBXLSupervisedDataset


CONFIG = {
    'ptbxl_data_path': 'use_data/ptb-xl',
    'cpsc_data_path': 'use_data/cpsc2018',
    'sampling_rate': 100,
    'batch_size': 256,
    'num_workers': 8,
}


def loader_for(dataset):
    kwargs = {
        'batch_size': CONFIG['batch_size'],
        'shuffle': False,
        'num_workers': CONFIG['num_workers'],
        'pin_memory': False,
        'persistent_workers': CONFIG['num_workers'] > 0,
    }
    if CONFIG['num_workers'] > 0:
        kwargs['prefetch_factor'] = 4
    return DataLoader(dataset, **kwargs)


def main():
    for split in ['train', 'val', 'test']:
        dataset = PTBXLSupervisedDataset(
            CONFIG['ptbxl_data_path'],
            sampling_rate=CONFIG['sampling_rate'],
            split=split,
        )
        loader = loader_for(dataset)
        for _ in tqdm(loader, desc=f"Building PTB-XL cache ({split})"):
            pass

    cpsc_dataset = CPSC2018Dataset(
        CONFIG['cpsc_data_path'],
        sampling_rate=CONFIG['sampling_rate'],
    )
    cpsc_loader = loader_for(cpsc_dataset)
    for _ in tqdm(cpsc_loader, desc="Building CPSC2018 cache"):
        pass


if __name__ == "__main__":
    main()
