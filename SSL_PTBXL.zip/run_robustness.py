import itertools

from evaluate import evaluate_model


CONFIG = {
    'data_path': 'use_data/ptb-xl',
    'cpsc_data_path': 'use_data/cpsc2018',
    'backbones': ['resnet', 'inceptiontime'],
    'methods': ['morphology_physio', 'physiological_moderate', 'physiological', 'naive_safe', 'naive_aggressive', 'scratch'],
    'label_fractions': [0.10, 1.0],
    'seeds': [42, 43, 44],
    'noise_types': ['baseline_wander', 'emg', 'electrode_motion', 'powerline'],
    'noise_levels': [0.0, 0.2, 0.5, 0.8, 1.0],
    'include_seed_in_path': True,
}


def run_all():
    for seed, backbone, method, label_fraction, noise_type, noise_level in itertools.product(
        CONFIG['seeds'],
        CONFIG['backbones'],
        CONFIG['methods'],
        CONFIG['label_fractions'],
        CONFIG['noise_types'],
        CONFIG['noise_levels'],
    ):
        use_pretrain = method != 'scratch'
        evaluate_model({
            'data_path': CONFIG['data_path'],
            'cpsc_data_path': CONFIG['cpsc_data_path'],
            'backbone': backbone,
            'seed': seed,
            'include_seed_in_path': CONFIG['include_seed_in_path'],
            'use_pretrain': use_pretrain,
            'aug_type': method if use_pretrain else 'physiological',
            'label_fraction': label_fraction,
            'eval_dataset': 'ptbxl',
            'noise_type': noise_type,
            'noise_level': noise_level,
            'threshold_strategy': 'validation_optimal',
            'allow_dummy': False,
        })


if __name__ == "__main__":
    run_all()
