from generate_plots import generate_augmentation_examples


if __name__ == "__main__":
    generate_augmentation_examples()
