import json
import os
import re

import pandas as pd


CONFIG = {
    'save_dir': 'save',
    'output_dir': 'save/tables',
}


RESULT_RE = re.compile(r'^(cpsc_)?results_frac_(\d+)(?:_noise_([a-z_]+)_([0-9p]+))?\.json$')


def infer_metadata(path_parts, filename):
    match = RESULT_RE.match(filename)
    if not match:
        return None

    eval_dataset = 'cpsc2018' if match.group(1) else 'ptbxl'
    label_fraction = int(match.group(2)) / 100.0
    noise_type = match.group(3)
    noise_level = None
    if match.group(4):
        noise_level = float(match.group(4).replace('p', '.'))

    metadata = {
        'eval_dataset': eval_dataset,
        'label_fraction': label_fraction,
        'label_percent': int(match.group(2)),
        'backbone': None,
        'seed': None,
        'method': None,
        'aug_type': None,
        'noise_type_from_name': noise_type,
        'noise_level_from_name': noise_level,
    }

    if not path_parts:
        return metadata

    metadata['backbone'] = path_parts[0]
    cursor = 1
    if len(path_parts) > 1 and path_parts[1].startswith('seed_'):
        metadata['seed'] = int(path_parts[1].replace('seed_', ''))
        cursor = 2

    if len(path_parts) > cursor:
        if path_parts[cursor] == 'scratch':
            metadata['method'] = 'scratch'
            metadata['aug_type'] = 'none'
        elif path_parts[cursor] == 'pretrain' and len(path_parts) > cursor + 1:
            metadata['method'] = 'pretrain'
            metadata['aug_type'] = path_parts[cursor + 1]

    return metadata


def collect_rows():
    rows = []
    save_dir = CONFIG['save_dir']
    for root, _, files in os.walk(save_dir):
        rel_root = os.path.relpath(root, save_dir)
        if rel_root == '.':
            path_parts = []
        else:
            path_parts = rel_root.split(os.sep)

        for filename in files:
            metadata = infer_metadata(path_parts, filename)
            if metadata is None:
                continue

            path = os.path.join(root, filename)
            with open(path, 'r', encoding='utf-8') as f:
                result = json.load(f)

            row = {
                **metadata,
                'path': path,
                'macro_f1': result.get('macro_f1'),
                'macro_auc': result.get('macro_auc'),
                'macro_f1_all_classes': result.get('macro_f1_all_classes'),
                'macro_f1_supported_classes': result.get('macro_f1_supported_classes'),
                'macro_auc_defined_classes': result.get('macro_auc_defined_classes'),
                'subset_accuracy': result.get('subset_accuracy'),
                'hamming_accuracy': result.get('hamming_accuracy'),
                'noise_type': result.get('noise_type') or metadata['noise_type_from_name'],
                'noise_level': result.get('noise_level') if result.get('noise_level') is not None else metadata['noise_level_from_name'],
                'threshold_strategy': result.get('threshold_strategy'),
            }

            for cls, metrics in result.get('class_wise', {}).items():
                row[f'{cls}_f1'] = metrics.get('f1')
                row[f'{cls}_auc'] = metrics.get('auc')
                row[f'{cls}_accuracy'] = metrics.get('accuracy')

            rows.append(row)

    return rows


def summarize(df):
    group_cols = [
        'backbone',
        'method',
        'aug_type',
        'label_percent',
        'eval_dataset',
        'noise_type',
        'noise_level',
    ]
    metric_cols = [
        'macro_f1',
        'macro_auc',
        'macro_f1_all_classes',
        'macro_f1_supported_classes',
        'macro_auc_defined_classes',
        'hamming_accuracy',
        'subset_accuracy',
    ]
    existing_metric_cols = [col for col in metric_cols if col in df.columns]

    grouped = df.groupby(group_cols, dropna=False)[existing_metric_cols]
    summary = grouped.agg(['mean', 'std', 'count']).reset_index()
    summary.columns = [
        '_'.join(col).strip('_') if isinstance(col, tuple) else col
        for col in summary.columns
    ]
    return summary


def main():
    rows = collect_rows()
    os.makedirs(CONFIG['output_dir'], exist_ok=True)

    df = pd.DataFrame(rows)
    raw_path = os.path.join(CONFIG['output_dir'], 'all_results.csv')
    df.to_csv(raw_path, index=False)

    if not df.empty:
        summary = summarize(df)
    else:
        summary = pd.DataFrame()

    summary_path = os.path.join(CONFIG['output_dir'], 'summary_results.csv')
    summary.to_csv(summary_path, index=False)

    print(f"Saved raw results to {raw_path}")
    print(f"Saved summary results to {summary_path}")
    print(f"Collected {len(df)} result files")


if __name__ == "__main__":
    main()
