import pandas as pd
import numpy as np
import os
import ast
import torch
from torch.utils.data import Dataset
import wfdb
from scipy.signal import butter, filtfilt

PHYSIOLOGICAL_AUGMENTATIONS = [
    'baseline_wander',
    'emg_noise',
    'electrode_motion',
    'powerline_interference',
]


def butter_bandpass_filter(data, lowcut=0.5, highcut=45.0, fs=100, order=3):
    nyq = 0.5 * fs
    low = lowcut / nyq
    high = highcut / nyq
    b, a = butter(order, [low, high], btype='band')
    y = filtfilt(b, a, data, axis=0)
    return y


def normalize_per_lead(signal):
    return (signal - np.mean(signal, axis=1, keepdims=True)) / (np.std(signal, axis=1, keepdims=True) + 1e-8)


def atomic_save_npy(path, array):
    tmp_path = f"{path}.{os.getpid()}.tmp.npy"
    np.save(tmp_path, array.astype(np.float32))
    os.replace(tmp_path, path)


class PTBXLSignalMixin:
    def _init_cache(self, cache_dir):
        self.cache_dir = cache_dir
        if self.cache_dir:
            os.makedirs(self.cache_dir, exist_ok=True)

    def _cache_path(self, row):
        if not self.cache_dir:
            return None
        return os.path.join(self.cache_dir, f"ptbxl_{int(row.name)}_{self.sampling_rate}hz.npy")

    def _load_signal(self, row):
        cache_path = self._cache_path(row)
        if cache_path and os.path.exists(cache_path):
            return np.load(cache_path)

        if self.sampling_rate == 100:
            file_path = os.path.join(self.data_path, row['filename_lr'])
        else:
            file_path = os.path.join(self.data_path, row['filename_hr'])

        signal, _ = wfdb.rdsamp(file_path)
        signal = butter_bandpass_filter(signal, fs=self.sampling_rate)
        signal = signal.transpose(1, 0).astype(np.float32)

        if cache_path:
            try:
                atomic_save_npy(cache_path, signal)
            except FileExistsError:
                pass
        return signal


class PTBXLContrastiveDataset(PTBXLSignalMixin, Dataset):
    def __init__(self, data_path, sampling_rate=100, split='train', aug_type='physiological', cache_dir=None):
        self.data_path = data_path
        self.sampling_rate = sampling_rate
        self.split = split
        self.aug_type = aug_type
        self._init_cache(cache_dir or os.path.join(data_path, f'cache_{sampling_rate}hz'))
        
        df = pd.read_csv(os.path.join(data_path, 'ptbxl_database.csv'), index_col='ecg_id')
        df.scp_codes = df.scp_codes.apply(lambda x: ast.literal_eval(x))
        
        # Diagnostic superclass mapping
        agg_df = pd.read_csv(os.path.join(data_path, 'scp_statements.csv'), index_col=0)
        agg_df = agg_df[agg_df.diagnostic == 1]
        
        def aggregate_diagnostic(y_dic):
            tmp = []
            for key in y_dic.keys():
                if key in agg_df.index:
                    tmp.append(agg_df.loc[key].diagnostic_class)
            return list(set(tmp))
            
        df['diagnostic_superclass'] = df.scp_codes.apply(aggregate_diagnostic)
        
        # Split: folds 1-8 train, 9 val, 10 test
        if split == 'train':
            self.df = df[df.strat_fold <= 8]
        elif split == 'val':
            self.df = df[df.strat_fold == 9]
        elif split == 'test':
            self.df = df[df.strat_fold == 10]
            
        self.classes = ['NORM', 'MI', 'STTC', 'CD', 'HYP']
        
    def add_baseline_wander(self, signal):
        # signal shape: [12, 1000]
        fs = self.sampling_rate
        length = signal.shape[1]
        t = np.arange(length) / fs
        augmented_signal = signal.copy()
        amp_range = (0.05, 0.25) if self._is_moderate_physiological() else (0.1, 0.5)
        for i in range(signal.shape[0]):
            freq = np.random.uniform(0.1, 0.5)
            std = np.std(signal[i])
            amp = np.random.uniform(*amp_range) * (std if std > 0 else 1.0)
            phase = np.random.uniform(0, 2 * np.pi)
            wander = amp * np.sin(2 * np.pi * freq * t + phase)
            augmented_signal[i] += wander
        return augmented_signal

    def add_emg_noise(self, signal):
        # signal shape: [12, 1000]
        augmented_signal = signal.copy()
        noise_range = (0.02, 0.10) if self._is_moderate_physiological() else (0.05, 0.20)
        for i in range(signal.shape[0]):
            std = np.std(signal[i])
            noise_std = np.random.uniform(*noise_range) * (std if std > 0 else 1.0)
            noise = np.random.normal(0, noise_std, size=signal.shape[1])
            augmented_signal[i] += noise
        return augmented_signal

    def add_electrode_motion(self, signal):
        # signal shape: [12, 1000]
        augmented_signal = signal.copy()
        shift_range = (-0.25, 0.25) if self._is_moderate_physiological() else (-0.5, 0.5)
        scale_range = (0.8, 1.2) if self._is_moderate_physiological() else (0.5, 1.5)
        for i in range(signal.shape[0]):
            choice = np.random.choice(['step_shift', 'amplitude_scaling', 'both'])
            std = np.std(signal[i])
            length = signal.shape[1]
            
            if choice in ['step_shift', 'both']:
                shift_idx = np.random.randint(int(length * 0.2), int(length * 0.8))
                shift_val = np.random.uniform(*shift_range) * (std if std > 0 else 1.0)
                augmented_signal[i, shift_idx:] += shift_val
                
            if choice in ['amplitude_scaling', 'both']:
                start_idx = np.random.randint(0, int(length * 0.5))
                end_idx = np.random.randint(int(length * 0.5), length)
                scale_factor = np.random.uniform(*scale_range)
                augmented_signal[i, start_idx:end_idx] *= scale_factor
                
        return augmented_signal

    def add_powerline_interference(self, signal):
        # signal shape: [12, 1000]
        fs = self.sampling_rate
        length = signal.shape[1]
        t = np.arange(length) / fs
        augmented_signal = signal.copy()
        amp_range = (0.005, 0.05) if self._is_moderate_physiological() else (0.01, 0.1)
        for i in range(signal.shape[0]):
            freq = np.random.choice([50.0, 60.0])
            std = np.std(signal[i])
            amp = np.random.uniform(*amp_range) * (std if std > 0 else 1.0)
            phase = np.random.uniform(0, 2 * np.pi)
            interference = amp * np.sin(2 * np.pi * freq * t + phase)
            augmented_signal[i] += interference
        return augmented_signal

    def add_naive_safe_augmentations(self, signal):
        # signal shape: [12, 1000]
        augmented = signal.copy()
        
        # Jittering (adding Gaussian noise with std=0.05)
        noise = np.random.normal(0, 0.05, size=augmented.shape)
        augmented += noise
        
        # Random scaling (multiplying by a factor between 0.8 and 1.2)
        scale_factor = np.random.uniform(0.8, 1.2)
        augmented *= scale_factor
        
        # Random zero masking (flatlining a segment of length 100)
        length = augmented.shape[1]
        start_idx = np.random.randint(0, length - 100 + 1)
        augmented[:, start_idx:start_idx+100] = 0.0
        
        return augmented

    def add_morphology_preserving_augmentations(self, signal):
        # Weak view: preserve ECG morphology while allowing mild acquisition
        # variation. This is intentionally weaker than naive_safe and avoids
        # masking diagnostic segments.
        augmented = signal.copy()
        noise = np.random.normal(0, 0.01, size=augmented.shape)
        augmented += noise
        scale_factor = np.random.uniform(0.95, 1.05)
        augmented *= scale_factor

        length = augmented.shape[1]
        max_shift = int(0.02 * length)
        shift = np.random.randint(-max_shift, max_shift + 1)
        if shift != 0:
            augmented = np.roll(augmented, shift, axis=1)
        return augmented

    def add_naive_aggressive_augmentations(self, signal):
        augmented = self.add_naive_safe_augmentations(signal)

        # Random sign inversion is intentionally treated as aggressive because it
        # can alter ECG lead polarity semantics.
        if np.random.random() < 0.5:
            augmented *= -1

        return augmented

    def add_naive_augmentations(self, signal):
        return self.add_naive_aggressive_augmentations(signal)

    def _augment(self, signal):
        augmented = signal.copy()
        augmentation_map = {
            'baseline_wander': self.add_baseline_wander,
            'emg_noise': self.add_emg_noise,
            'electrode_motion': self.add_electrode_motion,
            'powerline_interference': self.add_powerline_interference,
        }
        enabled_names = self._enabled_physiological_augmentations()
        augmentations = [augmentation_map[name] for name in enabled_names]
        np.random.shuffle(augmentations)
        max_to_apply = min(2, len(augmentations)) if self._is_moderate_physiological() else len(augmentations)
        num_to_apply = np.random.randint(1, max_to_apply + 1)
        for i in range(num_to_apply):
            augmented = augmentations[i](augmented)
        return augmented

    def _is_moderate_physiological(self):
        return self.aug_type in ('physiological_moderate', 'morphology_physio')

    def _enabled_physiological_augmentations(self):
        if self.aug_type in ('physiological', 'physiological_moderate', 'morphology_physio'):
            return PHYSIOLOGICAL_AUGMENTATIONS

        prefix = 'ablation_without_'
        if self.aug_type.startswith(prefix):
            removed = self.aug_type[len(prefix):]
            enabled = [name for name in PHYSIOLOGICAL_AUGMENTATIONS if name != removed]
            if len(enabled) == len(PHYSIOLOGICAL_AUGMENTATIONS):
                raise ValueError(f"Unknown physiological ablation target: {removed}")
            return enabled

        raise ValueError(f"Unknown physiological aug_type: {self.aug_type}")
    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        signal = self._load_signal(row)
        
        # Apply random physiological or naive noise augmentations
        if self.aug_type == 'morphology_physio':
            signal_aug1 = self.add_morphology_preserving_augmentations(signal)
            signal_aug2 = self._augment(signal)
        elif self.aug_type in ('physiological', 'physiological_moderate') or self.aug_type.startswith('ablation_without_'):
            signal_aug1 = self._augment(signal)
            signal_aug2 = self._augment(signal)
        elif self.aug_type in ('naive', 'naive_aggressive'):
            signal_aug1 = self.add_naive_augmentations(signal)
            signal_aug2 = self.add_naive_augmentations(signal)
        elif self.aug_type == 'naive_safe':
            signal_aug1 = self.add_naive_safe_augmentations(signal)
            signal_aug2 = self.add_naive_safe_augmentations(signal)
        else:
            raise ValueError(f"Unknown aug_type: {self.aug_type}")
        
        # Z-score normalization per lead
        signal_aug1 = normalize_per_lead(signal_aug1)
        signal_aug2 = normalize_per_lead(signal_aug2)
        
        # Convert to tensor [12, length]
        signal_aug1 = torch.tensor(signal_aug1, dtype=torch.float32)
        signal_aug2 = torch.tensor(signal_aug2, dtype=torch.float32)
        
        return signal_aug1, signal_aug2

class PTBXLSupervisedDataset(PTBXLSignalMixin, Dataset):
    def __init__(self, data_path, sampling_rate=100, split='train', cache_dir=None):
        self.data_path = data_path
        self.sampling_rate = sampling_rate
        self.split = split
        self._init_cache(cache_dir or os.path.join(data_path, f'cache_{sampling_rate}hz'))
        
        df = pd.read_csv(os.path.join(data_path, 'ptbxl_database.csv'), index_col='ecg_id')
        df.scp_codes = df.scp_codes.apply(lambda x: ast.literal_eval(x))
        
        # Diagnostic superclass mapping
        agg_df = pd.read_csv(os.path.join(data_path, 'scp_statements.csv'), index_col=0)
        agg_df = agg_df[agg_df.diagnostic == 1]
        
        def aggregate_diagnostic(y_dic):
            tmp = []
            for key in y_dic.keys():
                if key in agg_df.index:
                    tmp.append(agg_df.loc[key].diagnostic_class)
            return list(set(tmp))
            
        df['diagnostic_superclass'] = df.scp_codes.apply(aggregate_diagnostic)
        
        # Split: folds 1-8 train, 9 val, 10 test
        if split == 'train':
            self.df = df[df.strat_fold <= 8]
        elif split == 'val':
            self.df = df[df.strat_fold == 9]
        elif split == 'test':
            self.df = df[df.strat_fold == 10]
            
        self.classes = ['NORM', 'MI', 'STTC', 'CD', 'HYP']
        
    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        signal = self._load_signal(row)
        signal = normalize_per_lead(signal)
        
        # Multi-hot encode labels
        label = np.zeros(len(self.classes))
        for diag in row['diagnostic_superclass']:
            if diag in self.classes:
                label[self.classes.index(diag)] = 1
                
        # PyTorch expects (Channels, Length)
        signal = torch.tensor(signal, dtype=torch.float32)
        label = torch.tensor(label, dtype=torch.float32)
        
        return signal, label


class CPSC2018Dataset(Dataset):
    """
    External Validation Dataset: CPSC2018 (China Physiological Signal Challenge 2018)
    Used for testing the cross-database generalization of the PTB-XL trained model.
    """
    def __init__(self, data_path, sampling_rate=100, cache_dir=None):
        self.data_path = data_path
        self.sampling_rate = sampling_rate
        self.cache_dir = cache_dir or os.path.join(data_path, f'cache_{sampling_rate}hz')
        os.makedirs(self.cache_dir, exist_ok=True)
        self.files = []
        self.labels = []
        
        # Mapping from SNOMED-CT codes to PTB-XL diagnostic superclasses
        self.snomed_mapping = {
            '426783006': 'NORM', '426177001': 'NORM', '164102008': 'NORM',
            '164268008': 'STTC',  # AF
            '270492004': 'CD',    # I-AVB
            '445118002': 'CD',    # LBBB
            '59118001': 'CD',     # RBBB
            '251146004': 'STTC',  # PAC
            '164284003': 'CD',    # PVC
            '164294002': 'STTC',  # STD
            '164293008': 'STTC',  # STE
        }
        self.classes = ['NORM', 'MI', 'STTC', 'CD', 'HYP']
        
        if not os.path.exists(data_path):
            return
            
        # Scan data_path for .mat files
        for filename in sorted(os.listdir(data_path)):
            if filename.endswith('.mat'):
                record_id = filename[:-4]
                hea_path = os.path.join(data_path, f"{record_id}.hea")
                if os.path.exists(hea_path):
                    # Parse SNOMED-CT codes from the header file
                    dxs = self._parse_hea_dx(hea_path)
                    
                    # Map SNOMED-CT codes to PTB-XL classes
                    mapped_classes = []
                    for dx in dxs:
                        if dx in self.snomed_mapping:
                            mapped_classes.append(self.snomed_mapping[dx])
                            
                    # If we mapped any valid classes, keep the record
                    if mapped_classes:
                        self.files.append(record_id)
                        
                        # Create multi-hot label
                        label = np.zeros(len(self.classes))
                        for cls in mapped_classes:
                            if cls in self.classes:
                                label[self.classes.index(cls)] = 1
                        self.labels.append(label)
                        
    def _parse_hea_dx(self, hea_path):
        dxs = []
        with open(hea_path, 'r') as f:
            for line in f:
                if line.startswith('# Dx:'):
                    parts = line.strip().split(':')
                    if len(parts) > 1:
                        dxs = [d.strip() for d in parts[1].split(',')]
        return dxs
        
    def __len__(self):
        return len(self.files)

    def _cache_path(self, record_id):
        if not self.cache_dir:
            return None
        return os.path.join(self.cache_dir, f"{record_id}_{self.sampling_rate}hz.npy")

    def _load_signal(self, record_id):
        cache_path = self._cache_path(record_id)
        if cache_path and os.path.exists(cache_path):
            return np.load(cache_path)

        file_path = os.path.join(self.data_path, record_id)
        signal, _ = wfdb.rdsamp(file_path)

        # CPSC2018 is sampled at 500Hz, downsample to 100Hz by taking every 5th sample.
        if self.sampling_rate == 100:
            signal = signal[::5]

        signal = butter_bandpass_filter(signal, fs=self.sampling_rate)

        target_len = 1000
        if len(signal) < target_len:
            pad_width = target_len - len(signal)
            signal = np.pad(signal, ((0, pad_width), (0, 0)), mode='constant')
        else:
            signal = signal[:target_len]

        signal = signal.transpose(1, 0).astype(np.float32)
        if cache_path:
            try:
                atomic_save_npy(cache_path, signal)
            except FileExistsError:
                pass
        return signal
        
    def __getitem__(self, idx):
        record_id = self.files[idx]
        signal = self._load_signal(record_id)
        signal = normalize_per_lead(signal)
        
        # PyTorch expects (Channels, Length)
        signal = torch.tensor(signal, dtype=torch.float32)
        label = torch.tensor(self.labels[idx], dtype=torch.float32)
        
        return signal, label
