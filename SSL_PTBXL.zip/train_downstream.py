import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Subset, TensorDataset
import numpy as np
import os
import argparse
import random
from tqdm import tqdm

from dataset import PTBXLSupervisedDataset
from models import ResNet1D_Encoder, InceptionTime_Encoder, ECGClassifier


# Define DownstreamModel by combining the encoder and classifier
class DownstreamModel(nn.Module):
    def __init__(self, encoder, classifier):
        super(DownstreamModel, self).__init__()
        self.encoder = encoder
        self.classifier = classifier

    def forward(self, x):
        feat = self.encoder(x)
        return self.classifier(feat)


def get_dummy_downstream_data(num_samples=800):
    print("WARNING: Using dummy downstream data. Please configure correct data path.")
    X = torch.randn(num_samples, 12, 1000)
    y = torch.randint(0, 2, (num_samples, 5)).float()
    return TensorDataset(X, y)


# Hardcoded configuration parameters. Modify these values directly before running.
CONFIG = {
    'data_path': 'use_data/ptb-xl',
    'backbone': 'resnet',  # options: 'resnet', 'inceptiontime'
    'use_pretrain': False,  # True to load pre-trained weights from save/, False to train from scratch
    'aug_type': 'physiological',  # options: 'physiological', 'naive' (used if use_pretrain is True)
    'label_fraction': 0.1,  # Fraction of training data to use (e.g. 0.01, 0.05, 0.10, 1.0)
    'epochs': 50,
    'batch_size': None,
    'lr': 1e-4,
    'weight_decay': 1e-4,
    'early_stop_patience': 8,
    'early_stop_min_delta': 1e-4,
    'freeze_encoder_for_fewshot': False,
    'seed': 42,
    'allow_dummy': False,
    'include_seed_in_path': False,
    'num_workers': 8
}


class Hyperparams:
    def __init__(self, **entries):
        self.__dict__.update(entries)


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def get_save_root(args):
    save_root = os.path.join('save', args.backbone)
    if getattr(args, 'include_seed_in_path', False):
        save_root = os.path.join(save_root, f"seed_{args.seed}")
    return save_root


def resolve_downstream_batch_size(fraction, configured_batch_size):
    if configured_batch_size is not None:
        return configured_batch_size
    if fraction <= 0.01:
        return 32
    if fraction <= 0.05:
        return 64
    if fraction <= 0.10:
        return 128
    return 256


def train_downstream(config_overrides=None):
    config = CONFIG.copy()
    if config_overrides:
        config.update(config_overrides)
    args = Hyperparams(**config)
    set_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    # Standardize label_fraction
    fraction = args.label_fraction
    if fraction > 1.0:
        fraction = fraction / 100.0
    print(f"Label fraction: {fraction:.4f} ({fraction * 100:.1f}%)")
    batch_size = resolve_downstream_batch_size(fraction, args.batch_size)
    print(f"Downstream batch size: {batch_size}")
    print(f"Config: Epochs={args.epochs}, LR={args.lr}, Weight Decay={args.weight_decay}")

    # Load Data
    if os.path.exists(os.path.join(args.data_path, 'ptbxl_database.csv')):
        print(f"Loading PTB-XL dataset from {args.data_path}")
        train_dataset = PTBXLSupervisedDataset(args.data_path, sampling_rate=100, split='train')
        val_dataset = PTBXLSupervisedDataset(args.data_path, sampling_rate=100, split='val')
    else:
        if not args.allow_dummy:
            raise FileNotFoundError(
                f"PTB-XL database not found at {args.data_path}. "
                "Set CONFIG['data_path'] to the real dataset path or CONFIG['allow_dummy']=True for debugging."
            )
        print(f"PTB-XL database not found at {args.data_path}. Falling back to dummy data.")
        train_dataset = get_dummy_downstream_data(800)
        val_dataset = get_dummy_downstream_data(200)

    # Subset the training data for few-shot learning
    if fraction < 1.0:
        num_samples = len(train_dataset)
        subset_size = max(1, int(num_samples * fraction))
        # Use a fixed random seed for reproducible splits
        np.random.seed(args.seed)
        indices = np.random.choice(num_samples, subset_size, replace=False)
        train_dataset = Subset(train_dataset, indices)
        print(f"Subset size: {subset_size} samples out of {num_samples}")

    loader_kwargs = {
        'num_workers': args.num_workers,
        'pin_memory': device.type == 'cuda',
        'persistent_workers': args.num_workers > 0,
    }
    if args.num_workers > 0:
        loader_kwargs['prefetch_factor'] = 4

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, **loader_kwargs)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, **loader_kwargs)

    # Initialize model components
    if args.backbone == 'resnet':
        encoder = ResNet1D_Encoder(in_channels=12)
        in_dim = 512
    elif args.backbone == 'inceptiontime':
        encoder = InceptionTime_Encoder(in_channels=12)
        in_dim = 128
    else:
        raise ValueError(f"Unknown backbone: {args.backbone}")

    model_type = "scratch"
    if args.use_pretrain:
        # Load the pre-trained checkpoint dynamically resolved from save/
        actual_pretrain_path = os.path.join(get_save_root(args), 'pretrain', args.aug_type, 'best_ssl_encoder.pth')
        if os.path.exists(actual_pretrain_path):
            print(f"Loading pre-trained encoder weights from: {actual_pretrain_path}")
            encoder.load_state_dict(torch.load(actual_pretrain_path, weights_only=False, map_location='cpu'))
            model_type = "pretrain"
        else:
            print(
                f"WARNING: Pre-trained weights not found at '{actual_pretrain_path}'. Training from scratch.")

    classifier = ECGClassifier(in_dim=in_dim, num_classes=5)
    model = DownstreamModel(encoder, classifier).to(device)

    # Loss and Optimizer
    criterion = nn.BCEWithLogitsLoss()
    optimizer = optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)

    # Define save name based on fraction percentage and model_type
    pct = int(round(fraction * 100))
    if model_type == "pretrain":
        save_dir = os.path.join(get_save_root(args), 'pretrain', args.aug_type)
    else:
        save_dir = os.path.join(get_save_root(args), 'scratch')
    os.makedirs(save_dir, exist_ok=True)
    save_path = os.path.join(save_dir, f"downstream_frac_{pct}.pth")

    print(f"Starting downstream training for {args.epochs} epochs...")
    best_val_loss = float('inf')
    epochs_without_improvement = 0

    for epoch in range(args.epochs):
        model.train()
        train_loss = 0.0

        for X, y in tqdm(train_loader, desc=f"Epoch {epoch + 1}/{args.epochs}"):
            X, y = X.to(device, non_blocking=True), y.to(device, non_blocking=True)

            optimizer.zero_grad()
            outputs = model(X)
            loss = criterion(outputs, y)
            loss.backward()
            optimizer.step()

            train_loss += loss.item()

        # Validation Phase
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for X, y in val_loader:
                X, y = X.to(device, non_blocking=True), y.to(device, non_blocking=True)
                outputs = model(X)
                loss = criterion(outputs, y)
                val_loss += loss.item()

        mean_train_loss = train_loss / len(train_loader)
        mean_val_loss = val_loss / len(val_loader) if len(val_loader) > 0 else 0.0
        print(f"Epoch {epoch + 1:02d}: Train Loss: {mean_train_loss:.4f} | Val Loss: {mean_val_loss:.4f}")

        if mean_val_loss < best_val_loss - args.early_stop_min_delta:
            best_val_loss = mean_val_loss
            epochs_without_improvement = 0
            # Save the best model
            torch.save(model.state_dict(), save_path)
            print(f" -> Saved best model to {save_path}")
        else:
            epochs_without_improvement += 1
            if epochs_without_improvement >= args.early_stop_patience:
                print(
                    f"Early stopping at epoch {epoch + 1:02d}; "
                    f"best validation loss: {best_val_loss:.4f}"
                )
                break

    print(f"Training complete. Best model saved to {save_path}")


if __name__ == "__main__":
    train_downstream()
