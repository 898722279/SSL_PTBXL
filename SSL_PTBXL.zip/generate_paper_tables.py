import os

import pandas as pd


SUMMARY_PATH = os.path.join('save', 'tables', 'summary_results.csv')
OUT_DIR = os.path.join('save', 'tables', 'paper')

METHODS = [
    ('pretrain', 'morphology_physio', 'Morphology-physio SSL'),
    ('pretrain', 'physiological_moderate', 'Physiological-moderate SSL'),
    ('pretrain', 'physiological', 'Physiological SSL'),
    ('pretrain', 'naive_safe', 'Naive-safe SSL'),
    ('pretrain', 'naive_aggressive', 'Naive-aggressive SSL'),
    ('scratch', 'none', 'Scratch'),
]


def fmt_mean_std(mean, std):
    if pd.isna(mean):
        return ''
    if pd.isna(std):
        return f'{mean:.4f}'
    return f'{mean:.4f} ± {std:.4f}'


def load_summary():
    if not os.path.exists(SUMMARY_PATH):
        raise FileNotFoundError(f'Missing {SUMMARY_PATH}. Run collect_results.py first.')
    return pd.read_csv(SUMMARY_PATH)


def get_method_row(df, method, aug_type, label_percent, eval_dataset):
    sub = df[
        (df['method'] == method) &
        (df['aug_type'] == aug_type) &
        (df['label_percent'] == label_percent) &
        (df['eval_dataset'] == eval_dataset)
    ].copy()
    if sub.empty:
        return None

    clean = sub[sub['noise_type'].isna()]
    if not clean.empty:
        return clean.iloc[0]

    baseline = sub[(sub['noise_type'].notna()) & (sub['noise_level'].fillna(0.0) == 0.0)]
    if not baseline.empty:
        return baseline.iloc[0]
    return None


def write_table(df, filename):
    os.makedirs(OUT_DIR, exist_ok=True)
    csv_path = os.path.join(OUT_DIR, filename + '.csv')
    md_path = os.path.join(OUT_DIR, filename + '.md')
    df.to_csv(csv_path, index=False)
    with open(md_path, 'w', encoding='utf-8') as f:
        f.write(df.to_markdown(index=False))
        f.write('\n')
    print(f'Saved {csv_path}')
    print(f'Saved {md_path}')


def make_main_table(summary, eval_dataset, filename):
    rows = []
    for method, aug_type, label in METHODS:
        row = {'Method': label}
        for pct in [1, 5, 10, 100]:
            result = get_method_row(summary, method, aug_type, pct, eval_dataset)
            if result is None:
                row[f'{pct}% Macro F1'] = ''
                row[f'{pct}% Macro AUC'] = ''
                continue
            row[f'{pct}% Macro F1'] = fmt_mean_std(result['macro_f1_mean'], result['macro_f1_std'])
            row[f'{pct}% Macro AUC'] = fmt_mean_std(result['macro_auc_mean'], result['macro_auc_std'])
        rows.append(row)
    write_table(pd.DataFrame(rows), filename)


def make_ablation_table(summary):
    ablation = summary[
        (summary['eval_dataset'] == 'ptbxl') &
        (summary['aug_type'].fillna('').str.startswith('ablation_')) &
        (summary['noise_type'].isna())
    ].copy()
    name_map = {
        'ablation_without_baseline_wander': 'w/o baseline wander',
        'ablation_without_emg_noise': 'w/o EMG noise',
        'ablation_without_electrode_motion': 'w/o electrode motion',
        'ablation_without_powerline_interference': 'w/o powerline interference',
    }
    rows = []
    for aug_type, label in name_map.items():
        row = {'Variant': label}
        for pct in [10, 100]:
            result = ablation[(ablation['aug_type'] == aug_type) & (ablation['label_percent'] == pct)]
            if result.empty:
                row[f'{pct}% Macro F1'] = ''
                row[f'{pct}% Macro AUC'] = ''
                continue
            result = result.iloc[0]
            row[f'{pct}% Macro F1'] = fmt_mean_std(result['macro_f1_mean'], result['macro_f1_std'])
            row[f'{pct}% Macro AUC'] = fmt_mean_std(result['macro_auc_mean'], result['macro_auc_std'])
        rows.append(row)
    write_table(pd.DataFrame(rows), 'table_ablation_ptbxl')


def make_robustness_table(summary):
    robust = summary[
        (summary['eval_dataset'] == 'ptbxl') &
        (summary['label_percent'] == 100) &
        (summary['noise_type'].notna()) &
        (summary['noise_level'] == 1.0)
    ].copy()
    rows = []
    for method, aug_type, label in METHODS:
        row = {'Method': label}
        for noise_type in ['baseline_wander', 'emg', 'electrode_motion', 'powerline']:
            result = robust[
                (robust['method'] == method) &
                (robust['aug_type'] == aug_type) &
                (robust['noise_type'] == noise_type)
            ]
            if result.empty:
                row[noise_type] = ''
            else:
                result = result.iloc[0]
                row[noise_type] = fmt_mean_std(result['macro_f1_mean'], result['macro_f1_std'])
        rows.append(row)
    write_table(pd.DataFrame(rows), 'table_robustness_ptbxl_100_label_level_1')


def main():
    summary = load_summary()
    summary = summary[summary['backbone'] == 'resnet'].copy()
    make_main_table(summary, 'ptbxl', 'table_main_ptbxl')
    make_main_table(summary, 'cpsc2018', 'table_external_cpsc2018')
    make_ablation_table(summary)
    make_robustness_table(summary)


if __name__ == '__main__':
    main()
