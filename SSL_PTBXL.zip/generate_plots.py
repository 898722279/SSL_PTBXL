import json
import os

import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np
import pandas as pd
import torch
import wfdb
from sklearn.manifold import TSNE
from torch.utils.data import DataLoader

from dataset import PTBXLContrastiveDataset, PTBXLSupervisedDataset, butter_bandpass_filter
from models import ECGClassifier, InceptionTime_Encoder, ResNet1D_Encoder


CONFIG = {
    'backbone': 'resnet',
    'data_path': 'use_data/ptb-xl',
    'summary_path': 'save/tables/summary_results.csv',
    'seed': 42,
    'label_percent_for_tsne': 100,
}


plt.rcParams.update({
    'font.family': 'Arial',
    'font.size': 10,
    'axes.titlesize': 12,
    'axes.labelsize': 11,
    'legend.fontsize': 9,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'figure.dpi': 120,
    'savefig.dpi': 300,
    'axes.linewidth': 0.9,
    'pdf.fonttype': 42,
    'ps.fonttype': 42,
})


METHODS = [
    ('pretrain', 'morphology_physio'),
    ('pretrain', 'physiological_moderate'),
    ('pretrain', 'physiological'),
    ('pretrain', 'naive_safe'),
    ('pretrain', 'naive_aggressive'),
    ('scratch', 'none'),
]

METHOD_COLORS = {
    'morphology_physio': '#0072B2',
    'physiological_moderate': '#D55E00',
    'physiological': '#009E73',
    'naive_safe': '#CC79A7',
    'naive_aggressive': '#E69F00',
    'none': '#666666',
}

METHOD_MARKERS = {
    'morphology_physio': 'o',
    'physiological_moderate': 'D',
    'physiological': '^',
    'naive_safe': 's',
    'naive_aggressive': 'P',
    'none': 'X',
}

METHOD_LINESTYLES = {
    'morphology_physio': '-',
    'physiological_moderate': '--',
    'physiological': '-.',
    'naive_safe': ':',
    'naive_aggressive': (0, (3, 1, 1, 1)),
    'none': (0, (5, 2)),
}


METHOD_OFFSETS = {
    'morphology_physio': -0.18,
    'physiological_moderate': -0.11,
    'physiological': -0.04,
    'naive_safe': 0.04,
    'naive_aggressive': 0.11,
    'none': 0.18,
}


def add_bottom_legend(fig, ax_or_axes, ncol=3, y=0.02, fontsize=9):
    axes = np.ravel(ax_or_axes)
    handles, labels = [], []
    seen = set()
    for ax in axes:
        for handle, label in zip(*ax.get_legend_handles_labels()):
            if label not in seen:
                handles.append(handle)
                labels.append(label)
                seen.add(label)
    if handles:
        fig.legend(
            handles,
            labels,
            loc='lower center',
            bbox_to_anchor=(0.5, y),
            ncol=ncol,
            frameon=False,
            fontsize=fontsize,
            handlelength=2.8,
            columnspacing=1.4,
        )


class DownstreamModel(torch.nn.Module):
    def __init__(self, encoder, classifier):
        super().__init__()
        self.encoder = encoder
        self.classifier = classifier

    def forward(self, x):
        return self.classifier(self.encoder(x))


def build_model(backbone):
    if backbone == 'resnet':
        encoder = ResNet1D_Encoder(in_channels=12)
        in_dim = 512
    elif backbone == 'inceptiontime':
        encoder = InceptionTime_Encoder(in_channels=12)
        in_dim = 128
    else:
        raise ValueError(f"Unknown backbone: {backbone}")
    return DownstreamModel(encoder, ECGClassifier(in_dim=in_dim, num_classes=5))


def require_summary():
    if not os.path.exists(CONFIG['summary_path']):
        raise FileNotFoundError(f"Missing summary file: {CONFIG['summary_path']}. Run collect_results.py first.")
    return pd.read_csv(CONFIG['summary_path'])


def clean_summary_rows(df):
    """Keep ordinary evaluation rows and robustness baselines, excluding ablation rows."""
    return df[
        ~df['aug_type'].fillna('').str.startswith('ablation_')
    ].copy()


def method_label(method, aug_type):
    if method == 'scratch':
        return 'Scratch'
    labels = {
        'physiological': 'Physiological SSL',
        'physiological_moderate': 'Physiological-moderate SSL',
        'morphology_physio': 'Morphology-physio SSL',
        'naive_safe': 'Naive-safe SSL',
        'naive_aggressive': 'Naive-aggressive SSL',
        'naive': 'Naive SSL',
    }
    return labels.get(aug_type, aug_type)


def save_figure(fig, name):
    save_dir = os.path.join('save', CONFIG['backbone'], 'figures')
    os.makedirs(save_dir, exist_ok=True)
    path = os.path.join(save_dir, name)
    fig.savefig(path, dpi=300, bbox_inches='tight')
    pdf_path = os.path.splitext(path)[0] + '.pdf'
    fig.savefig(pdf_path, bbox_inches='tight')
    plt.close(fig)
    print(f"Saved {path}")
    print(f"Saved {pdf_path}")


def add_box(ax, xy, width, height, text, facecolor, edgecolor='#333333'):
    box = FancyBboxPatch(
        xy,
        width,
        height,
        boxstyle='round,pad=0.02,rounding_size=0.025',
        linewidth=1.1,
        edgecolor=edgecolor,
        facecolor=facecolor,
    )
    ax.add_patch(box)
    ax.text(
        xy[0] + width / 2,
        xy[1] + height / 2,
        text,
        ha='center',
        va='center',
        fontsize=10,
        wrap=True,
    )


def add_arrow(ax, start, end):
    arrow = FancyArrowPatch(
        start,
        end,
        arrowstyle='-|>',
        mutation_scale=12,
        linewidth=1.1,
        color='#333333',
    )
    ax.add_patch(arrow)


def generate_framework_overview():
    fig, ax = plt.subplots(figsize=(11.5, 5.2))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis('off')

    colors = {
        'data': '#D9EAF7',
        'aug': '#E8F4E5',
        'model': '#FFF3CC',
        'eval': '#F7E1E1',
        'table': '#ECE7F6',
    }

    add_box(ax, (0.04, 0.58), 0.15, 0.18, 'Unlabeled 12-lead ECG\nPTB-XL folds 1-8', colors['data'])
    add_box(ax, (0.25, 0.70), 0.18, 0.18, 'Generic augmentations\nnaive-safe\nnaive-aggressive', colors['aug'])
    add_box(ax, (0.25, 0.46), 0.18, 0.18, 'Physiological augmentations\nbaseline wander, EMG,\nelectrode motion, powerline', colors['aug'])
    add_box(ax, (0.50, 0.58), 0.16, 0.18, 'Contrastive pretraining\nEncoder + projection head\nNT-Xent loss', colors['model'])
    add_box(ax, (0.73, 0.58), 0.17, 0.18, 'Fine-tuning\nMulti-label classifier\nValidation thresholds', colors['model'])

    add_box(ax, (0.04, 0.17), 0.17, 0.16, 'Evaluation settings\n1%, 5%, 10%, 100% labels', colors['eval'])
    add_box(ax, (0.28, 0.17), 0.17, 0.16, 'Internal test\nPTB-XL fold 10', colors['eval'])
    add_box(ax, (0.51, 0.17), 0.17, 0.16, 'External test\nCPSC2018 mapped labels', colors['eval'])
    add_box(ax, (0.74, 0.17), 0.18, 0.16, 'Robustness test\nClinical noise injection', colors['eval'])

    add_arrow(ax, (0.19, 0.67), (0.25, 0.79))
    add_arrow(ax, (0.19, 0.67), (0.25, 0.55))
    add_arrow(ax, (0.43, 0.79), (0.50, 0.69))
    add_arrow(ax, (0.43, 0.55), (0.50, 0.65))
    add_arrow(ax, (0.66, 0.67), (0.73, 0.67))
    add_arrow(ax, (0.815, 0.58), (0.815, 0.33))
    add_arrow(ax, (0.21, 0.25), (0.28, 0.25))
    add_arrow(ax, (0.45, 0.25), (0.51, 0.25))
    add_arrow(ax, (0.68, 0.25), (0.74, 0.25))

    ax.text(
        0.5,
        0.95,
        'Study workflow for ECG self-supervised augmentation evaluation',
        ha='center',
        va='center',
        fontsize=14,
        fontweight='bold',
    )
    ax.text(
        0.5,
        0.04,
        'Main comparison: scratch vs. generic SSL vs. physiologically guided SSL',
        ha='center',
        va='center',
        fontsize=10,
        color='#444444',
    )
    save_figure(fig, 'framework_overview.png')


def get_method_row(df, method, aug_type, label_percent, eval_dataset):
    sub = df[
        (df['method'] == method) &
        (df['aug_type'] == aug_type) &
        (df['label_percent'] == label_percent) &
        (df['eval_dataset'] == eval_dataset)
    ].copy()
    if sub.empty:
        return None

    clean = sub[sub['noise_type'].isna()]
    if not clean.empty:
        return clean.iloc[0]

    baseline = sub[(sub['noise_type'].notna()) & (sub['noise_level'].fillna(0.0) == 0.0)]
    if not baseline.empty:
        return baseline.iloc[0]
    return None


def generate_few_shot_plot():
    df = clean_summary_rows(require_summary())
    df = df[(df['backbone'] == CONFIG['backbone'])].copy()

    label_percents = [1, 5, 10, 100]
    x = np.arange(len(label_percents))
    fig, axes = plt.subplots(2, 3, figsize=(12.6, 7.2), sharex=True, sharey=True)
    axes = axes.ravel()
    for ax, (method, aug_type) in zip(axes, METHODS):
        rows = []
        for pct in label_percents:
            row = get_method_row(df, method, aug_type, pct, 'ptbxl')
            if row is None:
                raise FileNotFoundError(f"Missing PTB-XL result for {method}/{aug_type}/{pct}%")
            rows.append(row)
        sub = pd.DataFrame(rows)
        ax.errorbar(
            x,
            sub['macro_f1_mean'],
            yerr=sub['macro_f1_std'].fillna(0.0),
            marker=METHOD_MARKERS[aug_type],
            linestyle=METHOD_LINESTYLES[aug_type],
            linewidth=2.1,
            markersize=7,
            capsize=3.5,
            elinewidth=1,
            color=METHOD_COLORS[aug_type],
            alpha=0.95,
        )
        ax.set_title(method_label(method, aug_type))
        ax.set_xticks(x)
        ax.set_xticklabels([f'{v}%' for v in label_percents])
        ax.set_xlim(-0.25, len(label_percents) - 0.75)
        ax.grid(True, linestyle=':', alpha=0.5)
    for ax in axes[3:]:
        ax.set_xlabel('Labeled training data (%)')
    for ax in axes[::3]:
        ax.set_ylabel('Macro F1-score')
    fig.suptitle('Label Efficiency on PTB-XL (ResNet1D)', y=0.98)
    fig.subplots_adjust(left=0.08, right=0.99, top=0.90, bottom=0.10, hspace=0.32, wspace=0.10)
    save_figure(fig, 'few_shot_comparison.png')


def generate_generalization_plot(label_percent=100):
    df = clean_summary_rows(require_summary())
    df = df[(df['backbone'] == CONFIG['backbone'])].copy()

    labels, f1, f1_std, auc, auc_std = [], [], [], [], []
    for method, aug_type in METHODS:
        row = get_method_row(df, method, aug_type, label_percent, 'cpsc2018')
        if row is None:
            raise FileNotFoundError(f"Missing CPSC2018 result for {method}/{aug_type}")
        labels.append(method_label(method, aug_type))
        f1.append(float(row['macro_f1_mean']))
        f1_std.append(float(row['macro_f1_std']) if pd.notna(row['macro_f1_std']) else 0.0)
        auc.append(float(row['macro_auc_mean']))
        auc_std.append(float(row['macro_auc_std']) if pd.notna(row['macro_auc_std']) else 0.0)

    x = np.arange(len(labels))
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.5), sharex=True)
    axes[0].bar(x, f1, yerr=f1_std, capsize=4, color=[METHOD_COLORS[m[1]] for m in METHODS])
    axes[1].bar(x, auc, yerr=auc_std, capsize=4, color=[METHOD_COLORS[m[1]] for m in METHODS])
    axes[0].set_ylabel('Macro F1-score')
    axes[1].set_ylabel('Macro AUC')
    axes[0].set_ylim(max(0, min(f1) - 0.06), min(1.0, max(f1) + 0.04))
    axes[1].set_ylim(max(0, min(auc) - 0.04), min(1.0, max(auc) + 0.03))
    for ax in axes:
        ax.set_xticks(x)
        ax.set_xticklabels(labels, rotation=25, ha='right')
        ax.grid(True, axis='y', linestyle=':', alpha=0.5)
    axes[0].set_title('Macro F1')
    axes[1].set_title('Macro AUC')
    fig.suptitle(f'Cross-database Generalization on CPSC2018 ({label_percent}% labels)')
    fig.tight_layout()
    save_figure(fig, 'generalization_comparison.png')


def generate_generalization_f1_by_label_plot():
    df = clean_summary_rows(require_summary())
    df = df[(df['backbone'] == CONFIG['backbone'])].copy()
    label_percents = [1, 5, 10, 100]
    x = np.arange(len(label_percents))
    fig, axes = plt.subplots(2, 3, figsize=(12.6, 7.2), sharex=True, sharey=True)
    axes = axes.ravel()
    for ax, (method, aug_type) in zip(axes, METHODS):
        rows = []
        for pct in label_percents:
            row = get_method_row(df, method, aug_type, pct, 'cpsc2018')
            if row is None:
                raise FileNotFoundError(f"Missing CPSC2018 result for {method}/{aug_type}/{pct}%")
            rows.append(row)
        sub = pd.DataFrame(rows)
        ax.errorbar(
            x,
            sub['macro_f1_mean'],
            yerr=sub['macro_f1_std'].fillna(0.0),
            marker=METHOD_MARKERS[aug_type],
            linestyle=METHOD_LINESTYLES[aug_type],
            linewidth=2.1,
            markersize=7,
            capsize=3.5,
            elinewidth=1,
            color=METHOD_COLORS[aug_type],
            alpha=0.95,
        )
        ax.set_title(method_label(method, aug_type))
        ax.set_xticks(x)
        ax.set_xticklabels([f'{v}%' for v in label_percents])
        ax.set_xlim(-0.25, len(label_percents) - 0.75)
        ax.grid(True, linestyle=':', alpha=0.5)
    for ax in axes[3:]:
        ax.set_xlabel('Labeled training data (%)')
    for ax in axes[::3]:
        ax.set_ylabel('Macro F1-score')
    fig.suptitle('External Generalization on CPSC2018 (ResNet1D)', y=0.98)
    fig.subplots_adjust(left=0.08, right=0.99, top=0.90, bottom=0.10, hspace=0.32, wspace=0.10)
    save_figure(fig, 'generalization_f1_by_label.png')


def generate_robustness_plot(label_percent=100):
    df = require_summary()
    df = df[
        (df['backbone'] == CONFIG['backbone']) &
        (df['eval_dataset'] == 'ptbxl') &
        (df['label_percent'] == label_percent) &
        (df['noise_type'].notna())
    ].copy()
    if df.empty:
        raise FileNotFoundError("Missing robustness results. Run run_robustness.py and collect_results.py first.")

    noise_types = sorted(df['noise_type'].dropna().unique())
    fig, axes = plt.subplots(1, len(noise_types), figsize=(5.2 * len(noise_types), 5.2), sharey=True)
    if len(noise_types) == 1:
        axes = [axes]

    for ax, noise_type in zip(axes, noise_types):
        noise_df = df[df['noise_type'] == noise_type]
        for method, aug_type in METHODS:
            sub = noise_df[(noise_df['method'] == method) & (noise_df['aug_type'] == aug_type)].sort_values('noise_level')
            if not sub.empty:
                ax.plot(
                    sub['noise_level'],
                    sub['macro_f1_mean'],
                    marker=METHOD_MARKERS[aug_type],
                    linestyle=METHOD_LINESTYLES[aug_type],
                    linewidth=2,
                    markersize=6,
                    color=METHOD_COLORS[aug_type],
                    alpha=0.95,
                    label=method_label(method, aug_type),
                )
        ax.set_title(noise_type.replace('_', ' ').title())
        ax.set_xlabel('Noise level')
        ax.grid(True, linestyle=':', alpha=0.5)
    axes[0].set_ylabel('Macro F1-score')
    add_bottom_legend(fig, axes, ncol=3, y=0.0, fontsize=9)
    fig.subplots_adjust(bottom=0.22, wspace=0.08)
    save_figure(fig, 'robustness_curves.png')


def generate_robustness_drop_plot(label_percent=100):
    all_df = clean_summary_rows(require_summary())
    all_df = all_df[(all_df['backbone'] == CONFIG['backbone'])].copy()
    df = all_df.copy()
    df = df[
        (df['backbone'] == CONFIG['backbone']) &
        (df['eval_dataset'] == 'ptbxl') &
        (df['label_percent'] == label_percent) &
        (df['noise_type'].notna())
    ].copy()
    if df.empty:
        raise FileNotFoundError("Missing robustness results. Run run_robustness.py and collect_results.py first.")

    noise_types = sorted(df['noise_type'].dropna().unique())
    fig, axes = plt.subplots(1, len(noise_types), figsize=(5.2 * len(noise_types), 5.2), sharey=True)
    if len(noise_types) == 1:
        axes = [axes]

    for ax, noise_type in zip(axes, noise_types):
        noise_df = df[df['noise_type'] == noise_type]
        for method, aug_type in METHODS:
            sub = noise_df[(noise_df['method'] == method) & (noise_df['aug_type'] == aug_type)].sort_values('noise_level')
            if sub.empty:
                continue
            baseline = get_method_row(all_df, method, aug_type, label_percent, 'ptbxl')
            if baseline is None:
                continue
            y = sub['macro_f1_mean'] - float(baseline['macro_f1_mean'])
            ax.plot(
                sub['noise_level'],
                y,
                marker=METHOD_MARKERS[aug_type],
                linestyle=METHOD_LINESTYLES[aug_type],
                linewidth=2,
                markersize=6,
                color=METHOD_COLORS[aug_type],
                alpha=0.95,
                label=method_label(method, aug_type),
            )
        ax.axhline(0, color='black', linewidth=0.8)
        ax.set_title(noise_type.replace('_', ' ').title())
        ax.set_xlabel('Noise level')
        ax.grid(True, linestyle=':', alpha=0.5)
    axes[0].set_ylabel('Macro F1 change from clean baseline')
    add_bottom_legend(fig, axes, ncol=3, y=0.0, fontsize=9)
    fig.subplots_adjust(bottom=0.22, wspace=0.08)
    save_figure(fig, 'robustness_drop_curves.png')


def generate_augmentation_examples(record_index=0):
    ds = PTBXLContrastiveDataset(CONFIG['data_path'], split='test', aug_type='physiological')
    row = ds.df.iloc[record_index]
    file_path = os.path.join(CONFIG['data_path'], row['filename_lr'])
    signal, _ = wfdb.rdsamp(file_path)
    signal = butter_bandpass_filter(signal, fs=100).transpose(1, 0)

    lead = 1
    t = np.arange(signal.shape[1]) / 100.0
    max_seconds = 8
    keep = t <= max_seconds
    t = t[keep]
    original = signal[lead, keep]
    variants = [
        ('Original', signal[lead, keep], '#333333'),
        ('Baseline wander', ds.add_baseline_wander(signal)[lead, keep], METHOD_COLORS['physiological']),
        ('EMG noise', ds.add_emg_noise(signal)[lead, keep], '#C44E52'),
        ('Electrode motion', ds.add_electrode_motion(signal)[lead, keep], '#8172B3'),
        ('Powerline interference', ds.add_powerline_interference(signal)[lead, keep], '#937860'),
        ('Naive-safe', ds.add_naive_safe_augmentations(signal)[lead, keep], METHOD_COLORS['naive_safe']),
        ('Naive-aggressive', ds.add_naive_aggressive_augmentations(signal)[lead, keep], METHOD_COLORS['naive_aggressive']),
    ]

    all_values = np.concatenate([v for _, v, _ in variants])
    y_min, y_max = np.percentile(all_values, [0.5, 99.5])
    y_pad = (y_max - y_min) * 0.18
    y_min -= y_pad
    y_max += y_pad

    fig, axes = plt.subplots(4, 2, figsize=(12.2, 9.8), sharex=True, sharey=True)
    axes = axes.ravel()
    for ax, (title, variant, color) in zip(axes, variants):
        ax.plot(t, original, color='#B8B8B8', linewidth=1.1, alpha=0.85, label='Original')
        ax.plot(t, variant, color=color, linewidth=1.05, alpha=0.95, label='Augmented')
        ax.set_title(title, pad=6)
        ax.set_ylim(y_min, y_max)
        ax.grid(True, linestyle=':', alpha=0.3)
        ax.tick_params(axis='both', labelsize=8)

    axes[-1].axis('off')
    for ax in axes[-3:-1]:
        ax.set_xlabel('Time (s)')
    add_bottom_legend(fig, axes[:-1], ncol=2, y=0.01, fontsize=9)
    fig.suptitle('ECG Augmentation Examples (Lead II)', y=0.98)
    fig.subplots_adjust(left=0.07, right=0.99, top=0.92, bottom=0.12, hspace=0.42, wspace=0.12)
    save_figure(fig, 'augmentation_examples.png')


def extract_features(model_path, device):
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Missing model for t-SNE: {model_path}")
    dataset = PTBXLSupervisedDataset(CONFIG['data_path'], split='test')
    loader = DataLoader(dataset, batch_size=64, shuffle=False)
    model = build_model(CONFIG['backbone']).to(device)
    model.load_state_dict(torch.load(model_path, map_location=device, weights_only=False))
    model.eval()

    features, targets = [], []
    with torch.no_grad():
        for x, y in loader:
            x = x.to(device)
            features.append(model.encoder(x).cpu().numpy())
            targets.append(y.numpy())
    return np.concatenate(features), np.concatenate(targets)


def generate_tsne_plot():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    root = os.path.join('save', CONFIG['backbone'], f"seed_{CONFIG['seed']}")
    pct = CONFIG['label_percent_for_tsne']
    paths = [
        ('Scratch', os.path.join(root, 'scratch', f'downstream_frac_{pct}.pth')),
        ('Naive-safe SSL', os.path.join(root, 'pretrain', 'naive_safe', f'downstream_frac_{pct}.pth')),
        ('Morphology-physio SSL', os.path.join(root, 'pretrain', 'morphology_physio', f'downstream_frac_{pct}.pth')),
    ]

    classes = ['NORM', 'MI', 'STTC', 'CD', 'HYP']
    colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd']
    fig, axes = plt.subplots(1, 3, figsize=(18, 5.5))

    for ax, (title, path) in zip(axes, paths):
        features, targets = extract_features(path, device)
        mask = targets.sum(axis=1) == 1
        features = features[mask]
        labels = np.argmax(targets[mask], axis=1)
        embedding = TSNE(n_components=2, perplexity=30, random_state=42, init='pca', learning_rate='auto').fit_transform(features)
        for class_idx, cls in enumerate(classes):
            idx = labels == class_idx
            ax.scatter(embedding[idx, 0], embedding[idx, 1], s=12, alpha=0.75, color=colors[class_idx], label=cls)
        ax.set_title(title)
        ax.set_xticks([])
        ax.set_yticks([])

    handles, labels = axes[-1].get_legend_handles_labels()
    fig.legend(handles, labels, loc='lower center', ncol=5, bbox_to_anchor=(0.5, -0.03))
    fig.suptitle(f't-SNE Representation Comparison (ResNet1D, {pct}% labels)')
    save_figure(fig, 'tsne_comparison.png')


if __name__ == "__main__":
    generate_framework_overview()
    generate_augmentation_examples()
    generate_few_shot_plot()
    generate_generalization_plot(label_percent=100)
    generate_generalization_f1_by_label_plot()
    generate_robustness_plot(label_percent=100)
    generate_robustness_drop_plot(label_percent=100)
    generate_tsne_plot()
