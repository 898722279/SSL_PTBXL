from run_experiments import CONFIG, run_all


CONFIG.update({
    'backbones': ['resnet'],
    'ssl_aug_types': ['morphology_physio', 'physiological_moderate', 'physiological', 'naive_safe', 'naive_aggressive'],
    'label_fractions': [0.01, 0.05, 0.10, 1.0],
    'seeds': [42],
    'ssl_epochs': 150,
    'downstream_epochs': 50,
    'run_ssl': True,
    'run_downstream': True,
    'run_ptbxl_eval': True,
    'run_cpsc_eval': True,
})


if __name__ == "__main__":
    run_all()
