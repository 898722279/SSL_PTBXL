import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
import numpy as np
import os
import argparse
import json
import random
from sklearn.metrics import roc_auc_score, f1_score, accuracy_score

from dataset import PTBXLSupervisedDataset
from models import ResNet1D_Encoder, InceptionTime_Encoder, ECGClassifier


# Define DownstreamModel by combining the encoder and classifier
class DownstreamModel(nn.Module):
    def __init__(self, encoder, classifier):
        super(DownstreamModel, self).__init__()
        self.encoder = encoder
        self.classifier = classifier

    def forward(self, x):
        feat = self.encoder(x)
        return self.classifier(feat)


def get_dummy_downstream_data(num_samples=200):
    print("WARNING: Using dummy downstream test data.")
    X = torch.randn(num_samples, 12, 1000)
    y = torch.randint(0, 2, (num_samples, 5)).float()
    return TensorDataset(X, y)


# Hardcoded configuration parameters. Modify these values directly before running.
CONFIG = {
    'backbone': 'resnet',             # options: 'resnet', 'inceptiontime'
    'use_pretrain': True,             # True to evaluate fine-tuned model, False to evaluate scratch model
    'aug_type': 'physiological',      # options: 'physiological', 'naive' (used if use_pretrain is True)
    'label_fraction': 0.1,            # options: 0.01, 0.05, 0.10, 1.0
    'eval_dataset': 'ptbxl',          # options: 'ptbxl', 'cpsc2018'
    'noise_type': None,               # options: None, 'baseline_wander', 'emg', 'electrode_motion', 'powerline'
    'noise_level': 0.0,               # noise intensity scaling factor
    'threshold_strategy': 'validation_optimal',  # options: 'validation_optimal', 'fixed_0.5'
    'data_path': 'use_data/ptb-xl',
    'cpsc_data_path': 'use_data/cpsc2018',
    'seed': 42,
    'allow_dummy': False,
    'include_seed_in_path': False,
    'eval_batch_size': 256,
    'num_workers': 8
}


class Hyperparams:
    def __init__(self, **entries):
        self.__dict__.update(entries)


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def build_model(backbone, device):
    if backbone == 'resnet':
        encoder = ResNet1D_Encoder(in_channels=12)
        in_dim = 512
    elif backbone == 'inceptiontime':
        encoder = InceptionTime_Encoder(in_channels=12)
        in_dim = 128
    else:
        raise ValueError(f"Unknown backbone: {backbone}")

    classifier = ECGClassifier(in_dim=in_dim, num_classes=5)
    return DownstreamModel(encoder, classifier).to(device)


def get_save_root(args):
    save_root = os.path.join('save', args.backbone)
    if getattr(args, 'include_seed_in_path', False):
        save_root = os.path.join(save_root, f"seed_{args.seed}")
    return save_root


def collect_predictions(model, loader, device, args, apply_noise=False):
    all_preds = []
    all_targets = []

    with torch.no_grad():
        for X, y in loader:
            if apply_noise and args.noise_type is not None and args.noise_level > 0.0:
                X_np = X.numpy()
                perturbed_list = []
                for b in range(X_np.shape[0]):
                    signal = X_np[b]
                    if args.noise_type == 'baseline_wander':
                        perturbed = add_baseline_wander(signal, sampling_rate=100, noise_level=args.noise_level)
                    elif args.noise_type == 'emg':
                        perturbed = add_emg_noise(signal, noise_level=args.noise_level)
                    elif args.noise_type == 'electrode_motion':
                        perturbed = add_electrode_motion(signal, noise_level=args.noise_level)
                    elif args.noise_type == 'powerline':
                        perturbed = add_powerline_interference(signal, sampling_rate=100, noise_level=args.noise_level)
                    else:
                        perturbed = signal

                    perturbed = (perturbed - np.mean(perturbed, axis=1, keepdims=True)) / (
                                np.std(perturbed, axis=1, keepdims=True) + 1e-8)
                    perturbed_list.append(perturbed)
                X = torch.tensor(np.array(perturbed_list), dtype=torch.float32)

            X = X.to(device, non_blocking=True)
            outputs = model(X)
            preds = torch.sigmoid(outputs).cpu().numpy()
            all_preds.append(preds)
            all_targets.append(y.numpy())

    return np.concatenate(all_preds, axis=0), np.concatenate(all_targets, axis=0)


def find_best_thresholds(y_true, y_prob):
    thresholds = []
    grid = np.arange(0.05, 0.96, 0.01)
    for class_idx in range(y_true.shape[1]):
        best_threshold = 0.5
        best_f1 = -1.0
        for threshold in grid:
            f1 = f1_score(y_true[:, class_idx], (y_prob[:, class_idx] > threshold).astype(int), zero_division=0)
            if f1 > best_f1:
                best_f1 = f1
                best_threshold = threshold
        thresholds.append(best_threshold)
    return np.array(thresholds)


def safe_auc(y_true, y_score):
    if len(np.unique(y_true)) < 2:
        return None
    return float(roc_auc_score(y_true, y_score))


def finite_mean(values):
    valid = [v for v in values if v is not None and np.isfinite(v)]
    if not valid:
        return None
    return float(np.mean(valid))


def add_baseline_wander(signal, sampling_rate=100, noise_level=1.0):
    fs = sampling_rate
    length = signal.shape[1]
    t = np.arange(length) / fs
    augmented_signal = signal.copy()
    for i in range(signal.shape[0]):
        freq = np.random.uniform(0.1, 0.5)
        std = np.std(signal[i])
        amp = np.random.uniform(0.1, 0.5) * (std if std > 0 else 1.0) * noise_level
        phase = np.random.uniform(0, 2 * np.pi)
        wander = amp * np.sin(2 * np.pi * freq * t + phase)
        augmented_signal[i] += wander
    return augmented_signal


def add_emg_noise(signal, noise_level=1.0):
    augmented_signal = signal.copy()
    for i in range(signal.shape[0]):
        std = np.std(signal[i])
        noise_std = np.random.uniform(0.05, 0.20) * (std if std > 0 else 1.0) * noise_level
        noise = np.random.normal(0, noise_std, size=signal.shape[1])
        augmented_signal[i] += noise
    return augmented_signal


def add_electrode_motion(signal, noise_level=1.0):
    augmented_signal = signal.copy()
    for i in range(signal.shape[0]):
        choice = np.random.choice(['step_shift', 'amplitude_scaling', 'both'])
        std = np.std(signal[i])
        length = signal.shape[1]

        if choice in ['step_shift', 'both']:
            shift_idx = np.random.randint(int(length * 0.2), int(length * 0.8))
            shift_val = np.random.uniform(-0.5, 0.5) * (std if std > 0 else 1.0) * noise_level
            augmented_signal[i, shift_idx:] += shift_val

        if choice in ['amplitude_scaling', 'both']:
            start_idx = np.random.randint(0, int(length * 0.5))
            end_idx = np.random.randint(int(length * 0.5), length)
            raw_scale = np.random.uniform(0.5, 1.5)
            scale_factor = 1.0 + (raw_scale - 1.0) * noise_level
            augmented_signal[i, start_idx:end_idx] *= scale_factor

    return augmented_signal


def add_powerline_interference(signal, sampling_rate=100, noise_level=1.0):
    fs = sampling_rate
    length = signal.shape[1]
    t = np.arange(length) / fs
    augmented_signal = signal.copy()
    for i in range(signal.shape[0]):
        freq = np.random.choice([50.0, 60.0])
        std = np.std(signal[i])
        amp = np.random.uniform(0.01, 0.1) * (std if std > 0 else 1.0) * noise_level
        phase = np.random.uniform(0, 2 * np.pi)
        interference = amp * np.sin(2 * np.pi * freq * t + phase)
        augmented_signal[i] += interference
    return augmented_signal


def evaluate_model(config_overrides=None):
    config = CONFIG.copy()
    if config_overrides:
        config.update(config_overrides)
    args = Hyperparams(**config)
    set_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    # Resolve paths based on structured directory layout
    pct = int(round(args.label_fraction * 100))
    if args.use_pretrain:
        model_dir = os.path.join(get_save_root(args), 'pretrain', args.aug_type)
    else:
        model_dir = os.path.join(get_save_root(args), 'scratch')

    model_path = os.path.join(model_dir, f"downstream_frac_{pct}.pth")
    
    noise_suffix = ""
    if args.noise_type is not None and args.noise_level > 0.0:
        level_text = str(args.noise_level).replace('.', 'p')
        noise_suffix = f"_noise_{args.noise_type}_{level_text}"

    if args.eval_dataset == 'cpsc2018':
        output_path = os.path.join(model_dir, f"cpsc_results_frac_{pct}{noise_suffix}.json")
    else:
        output_path = os.path.join(model_dir, f"results_frac_{pct}{noise_suffix}.json")

    args.model_path = model_path
    args.output_path = output_path

    print(f"Evaluating model: {args.model_path}")
    print(f"Results will be saved to: {args.output_path}")

    # Load Data
    if args.eval_dataset == 'cpsc2018':
        print(f"Loading CPSC2018 test dataset from {args.cpsc_data_path}")
        if os.path.exists(args.cpsc_data_path):
            from dataset import CPSC2018Dataset
            test_dataset = CPSC2018Dataset(args.cpsc_data_path, sampling_rate=100)
            if len(test_dataset) == 0:
                print("Warning: CPSC2018 dataset is empty. Falling back to dummy test data.")
                test_dataset = get_dummy_downstream_data(200)
        else:
            if not args.allow_dummy:
                raise FileNotFoundError(f"CPSC2018 data path not found: {args.cpsc_data_path}")
            print(f"CPSC2018 data path {args.cpsc_data_path} not found. Falling back to dummy test data.")
            test_dataset = get_dummy_downstream_data(200)
    else:
        if os.path.exists(os.path.join(args.data_path, 'ptbxl_database.csv')):
            print(f"Loading PTB-XL test set from {args.data_path}")
            test_dataset = PTBXLSupervisedDataset(args.data_path, sampling_rate=100, split='test')
        else:
            if not args.allow_dummy:
                raise FileNotFoundError(f"PTB-XL database not found at {args.data_path}")
            print(f"PTB-XL database not found at {args.data_path}. Falling back to dummy test data.")
            test_dataset = get_dummy_downstream_data(200)

    loader_kwargs = {
        'num_workers': args.num_workers,
        'pin_memory': device.type == 'cuda',
        'persistent_workers': args.num_workers > 0,
    }
    if args.num_workers > 0:
        loader_kwargs['prefetch_factor'] = 4

    test_loader = DataLoader(test_dataset, batch_size=args.eval_batch_size, shuffle=False, **loader_kwargs)

    # Reconstruct Model architecture
    model = build_model(args.backbone, device)

    # Load model weights
    if not os.path.exists(args.model_path):
        print(f"[Error] Checkpoint file not found: {args.model_path}")
        return

    model.load_state_dict(torch.load(args.model_path, weights_only=False, map_location=device))
    model.eval()

    if args.threshold_strategy == 'validation_optimal':
        if not os.path.exists(os.path.join(args.data_path, 'ptbxl_database.csv')):
            raise FileNotFoundError(f"PTB-XL validation data not found at {args.data_path}")
        print("Selecting class-wise thresholds on PTB-XL validation fold (Fold 9)...")
        val_dataset = PTBXLSupervisedDataset(args.data_path, sampling_rate=100, split='val')
        val_loader = DataLoader(val_dataset, batch_size=args.eval_batch_size, shuffle=False, **loader_kwargs)
        val_preds, val_targets = collect_predictions(model, val_loader, device, args, apply_noise=False)
        thresholds = find_best_thresholds(val_targets, val_preds)
    elif args.threshold_strategy == 'fixed_0.5':
        thresholds = np.full(5, 0.5)
    else:
        raise ValueError(f"Unknown threshold_strategy: {args.threshold_strategy}")

    print("Running inference on test set (Fold 10)...")
    all_preds, all_targets = collect_predictions(model, test_loader, device, args, apply_noise=True)

    # Compute metrics. For external mapped datasets, some PTB-XL superclasses may
    # be absent. AUC is only defined for classes with both positive and negative
    # samples, so we report both all-class F1 and valid-class headline metrics.
    pred_labels = (all_preds > thresholds.reshape(1, -1)).astype(int)
    acc = accuracy_score(all_targets, pred_labels)

    class_support = all_targets.sum(axis=0).astype(int)
    class_negative_support = (all_targets.shape[0] - class_support).astype(int)
    valid_auc_mask = (class_support > 0) & (class_negative_support > 0)
    valid_f1_mask = class_support > 0

    macro_f1_all = f1_score(all_targets, pred_labels, average='macro', zero_division=0)
    macro_f1_valid = f1_score(
        all_targets[:, valid_f1_mask],
        pred_labels[:, valid_f1_mask],
        average='macro',
        zero_division=0,
    ) if np.any(valid_f1_mask) else None

    # Hamming accuracy (average accuracy per label)
    hamming_acc = 1.0 - np.mean(all_targets != pred_labels)

    # Class-wise metrics for detailed display
    classes = ['NORM', 'MI', 'STTC', 'CD', 'HYP']
    class_metrics = {}
    class_aucs = []
    print("\n==================================================")
    print(f"Test Performance Results")
    print("==================================================")
    for i, cls in enumerate(classes):
        cls_auc = safe_auc(all_targets[:, i], all_preds[:, i])
        cls_f1 = f1_score(all_targets[:, i], pred_labels[:, i], zero_division=0)
        cls_acc = accuracy_score(all_targets[:, i], pred_labels[:, i])
        class_aucs.append(cls_auc)
        auc_text = f"{cls_auc:.4f}" if cls_auc is not None else "NA"
        print(
            f"Class {cls:5s} | Support: {class_support[i]:4d} | "
            f"Accuracy: {cls_acc:.4f} | ROC-AUC: {auc_text} | F1-Score: {cls_f1:.4f}"
        )
        class_metrics[cls] = {
            'accuracy': float(cls_acc),
            'auc': cls_auc,
            'f1': float(cls_f1),
            'support': int(class_support[i]),
            'negative_support': int(class_negative_support[i]),
            'auc_defined': bool(valid_auc_mask[i]),
            'f1_in_valid_macro': bool(valid_f1_mask[i])
        }

    macro_auc_valid = finite_mean(class_aucs)
    macro_auc_all = macro_auc_valid

    print("-" * 50)
    print(f"Subset Accuracy: {acc:.4f}")
    print(f"Hamming Accuracy: {hamming_acc:.4f}")
    print(f"Macro F1-Score (all classes): {macro_f1_all:.4f}")
    if macro_f1_valid is not None:
        print(f"Macro F1-Score (supported classes): {macro_f1_valid:.4f}")
    print(f"Macro AUC-ROC (defined classes): {macro_auc_valid:.4f}" if macro_auc_valid is not None else "Macro AUC-ROC (defined classes): NA")
    print("==================================================")

    # Save to JSON
    results = {
        'model_path': args.model_path,
        'backbone': args.backbone,
        'noise_type': args.noise_type,
        'noise_level': args.noise_level,
        'threshold_strategy': args.threshold_strategy,
        'thresholds': thresholds.tolist(),
        'subset_accuracy': float(acc),
        'hamming_accuracy': float(hamming_acc),
        'macro_f1': float(macro_f1_valid if macro_f1_valid is not None else macro_f1_all),
        'macro_auc': macro_auc_valid,
        'macro_f1_all_classes': float(macro_f1_all),
        'macro_f1_supported_classes': float(macro_f1_valid) if macro_f1_valid is not None else None,
        'macro_auc_defined_classes': macro_auc_valid,
        'valid_f1_classes': [classes[i] for i in np.where(valid_f1_mask)[0]],
        'valid_auc_classes': [classes[i] for i in np.where(valid_auc_mask)[0]],
        'class_wise': class_metrics
    }

    # Ensure directory of output_path exists
    output_dir = os.path.dirname(args.output_path)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    with open(args.output_path, 'w') as f:
        json.dump(results, f, indent=4, allow_nan=False)

    print(f"Saved evaluation results to {args.output_path}")


if __name__ == "__main__":
    evaluate_model()
