import itertools
import os

from train_ssl import train_ssl
from train_downstream import train_downstream
from evaluate import evaluate_model


CONFIG = {
    'data_path': 'use_data/ptb-xl',
    'cpsc_data_path': 'use_data/cpsc2018',
    'backbones': ['resnet', 'inceptiontime'],
    'ssl_aug_types': ['morphology_physio', 'physiological_moderate', 'physiological', 'naive_safe', 'naive_aggressive'],
    'label_fractions': [0.01, 0.05, 0.10, 1.0],
    'seeds': [42, 43, 44],
    'ssl_epochs': 150,
    'downstream_epochs': 50,
    'ssl_batch_size': 1024,
    'downstream_batch_size': None,
    'num_workers': 8,
    'ssl_lr': 2e-3,
    'downstream_lr': 1e-4,
    'weight_decay': 1e-4,
    'early_stop_patience': 8,
    'early_stop_min_delta': 1e-4,
    'ssl_early_stop_patience': 15,
    'ssl_early_stop_min_delta': 1e-4,
    'temperature': 0.5,
    'include_seed_in_path': True,
    'run_ssl': True,
    'run_downstream': True,
    'run_ptbxl_eval': True,
    'run_cpsc_eval': True,
}


def save_root(backbone, seed):
    root = os.path.join('save', backbone)
    if CONFIG['include_seed_in_path']:
        root = os.path.join(root, f"seed_{seed}")
    return root


def downstream_path(backbone, seed, use_pretrain, aug_type, label_fraction):
    pct = int(round(label_fraction * 100))
    if use_pretrain:
        return os.path.join(save_root(backbone, seed), 'pretrain', aug_type, f"downstream_frac_{pct}.pth")
    return os.path.join(save_root(backbone, seed), 'scratch', f"downstream_frac_{pct}.pth")


def ssl_path(backbone, seed, aug_type):
    return os.path.join(save_root(backbone, seed), 'pretrain', aug_type, 'best_ssl_encoder.pth')


def result_path(backbone, seed, use_pretrain, aug_type, label_fraction, eval_dataset):
    pct = int(round(label_fraction * 100))
    filename = f"cpsc_results_frac_{pct}.json" if eval_dataset == 'cpsc2018' else f"results_frac_{pct}.json"
    if use_pretrain:
        return os.path.join(save_root(backbone, seed), 'pretrain', aug_type, filename)
    return os.path.join(save_root(backbone, seed), 'scratch', filename)


def run_all():
    for seed, backbone in itertools.product(CONFIG['seeds'], CONFIG['backbones']):
        base = {
            'data_path': CONFIG['data_path'],
            'backbone': backbone,
            'seed': seed,
            'weight_decay': CONFIG['weight_decay'],
            'early_stop_patience': CONFIG['early_stop_patience'],
            'early_stop_min_delta': CONFIG['early_stop_min_delta'],
            'include_seed_in_path': CONFIG['include_seed_in_path'],
            'allow_dummy': False,
            'num_workers': CONFIG['num_workers'],
        }

        if CONFIG['run_ssl']:
            for aug_type in CONFIG['ssl_aug_types']:
                target_path = ssl_path(backbone, seed, aug_type)
                if os.path.exists(target_path):
                    print(f"[skip] SSL exists: {target_path}")
                    continue
                train_ssl({
                    **base,
                    'aug_type': aug_type,
                    'epochs': CONFIG['ssl_epochs'],
                    'batch_size': CONFIG['ssl_batch_size'],
                    'lr': CONFIG['ssl_lr'],
                    'early_stop_patience': CONFIG['ssl_early_stop_patience'],
                    'early_stop_min_delta': CONFIG['ssl_early_stop_min_delta'],
                    'temperature': CONFIG['temperature'],
                })

        if CONFIG['run_downstream']:
            for aug_type, label_fraction in itertools.product(CONFIG['ssl_aug_types'], CONFIG['label_fractions']):
                target_path = downstream_path(backbone, seed, True, aug_type, label_fraction)
                if os.path.exists(target_path):
                    print(f"[skip] Downstream exists: {target_path}")
                    continue
                train_downstream({
                    **base,
                    'use_pretrain': True,
                    'aug_type': aug_type,
                    'label_fraction': label_fraction,
                    'epochs': CONFIG['downstream_epochs'],
                    'batch_size': CONFIG['downstream_batch_size'],
                    'lr': CONFIG['downstream_lr'],
                })

            for label_fraction in CONFIG['label_fractions']:
                target_path = downstream_path(backbone, seed, False, 'physiological', label_fraction)
                if os.path.exists(target_path):
                    print(f"[skip] Downstream exists: {target_path}")
                    continue
                train_downstream({
                    **base,
                    'use_pretrain': False,
                    'aug_type': 'physiological',
                    'label_fraction': label_fraction,
                    'epochs': CONFIG['downstream_epochs'],
                    'batch_size': CONFIG['downstream_batch_size'],
                    'lr': CONFIG['downstream_lr'],
                })

        eval_base = {
            **base,
            'cpsc_data_path': CONFIG['cpsc_data_path'],
            'threshold_strategy': 'validation_optimal',
        }

        if CONFIG['run_ptbxl_eval']:
            for aug_type, label_fraction in itertools.product(CONFIG['ssl_aug_types'], CONFIG['label_fractions']):
                target_path = result_path(backbone, seed, True, aug_type, label_fraction, 'ptbxl')
                if os.path.exists(target_path):
                    print(f"[skip] PTB-XL result exists: {target_path}")
                    continue
                evaluate_model({
                    **eval_base,
                    'use_pretrain': True,
                    'aug_type': aug_type,
                    'label_fraction': label_fraction,
                    'eval_dataset': 'ptbxl',
                    'noise_type': None,
                    'noise_level': 0.0,
                })

            for label_fraction in CONFIG['label_fractions']:
                target_path = result_path(backbone, seed, False, 'physiological', label_fraction, 'ptbxl')
                if os.path.exists(target_path):
                    print(f"[skip] PTB-XL result exists: {target_path}")
                    continue
                evaluate_model({
                    **eval_base,
                    'use_pretrain': False,
                    'aug_type': 'physiological',
                    'label_fraction': label_fraction,
                    'eval_dataset': 'ptbxl',
                    'noise_type': None,
                    'noise_level': 0.0,
                })

        if CONFIG['run_cpsc_eval']:
            for aug_type, label_fraction in itertools.product(CONFIG['ssl_aug_types'], CONFIG['label_fractions']):
                target_path = result_path(backbone, seed, True, aug_type, label_fraction, 'cpsc2018')
                if os.path.exists(target_path):
                    print(f"[skip] CPSC result exists: {target_path}")
                    continue
                evaluate_model({
                    **eval_base,
                    'use_pretrain': True,
                    'aug_type': aug_type,
                    'label_fraction': label_fraction,
                    'eval_dataset': 'cpsc2018',
                    'noise_type': None,
                    'noise_level': 0.0,
                })

            for label_fraction in CONFIG['label_fractions']:
                target_path = result_path(backbone, seed, False, 'physiological', label_fraction, 'cpsc2018')
                if os.path.exists(target_path):
                    print(f"[skip] CPSC result exists: {target_path}")
                    continue
                evaluate_model({
                    **eval_base,
                    'use_pretrain': False,
                    'aug_type': 'physiological',
                    'label_fraction': label_fraction,
                    'eval_dataset': 'cpsc2018',
                    'noise_type': None,
                    'noise_level': 0.0,
                })


if __name__ == "__main__":
    run_all()
